package com.example.islamiclife;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final String[] tasks = {
        "پنځه وخته لمونځ", "د سهار اذکار", "د ماښام اذکار", "د قرآن یو پاره",
        "د قرآن د معنا مطالعه", "د حدیث ورځنی درس", "د «الفوائد» درس",
        "استغفار او توبه", "د مور او پلار یا کورنۍ خدمت", "یوه پټه نېکي",
        "د خوب مخکې محاسبه"
    };
    private final String[] quranTopics = {
        "هدایت، تقوا او د قرآن پیغام","د الله تعالی د احکامو اطاعت","اخلاص او د نېکو خلکو صفتونه",
        "د الله تعالی رحمت او مغفرت","د کورنۍ او ټولنې حقوق","د احکامو پابندي","صبر او د ایمان ساتنه",
        "د الله تعالی قدرت او نعمتونه","د پیغمبرانو کیسې او عبرتونه","توبه او د الله تعالی رحمت",
        "د عمل او نیت اهمیت","د الله تعالی پر وعدو باور","د حق پیروي","د آخرت یاد","د انسان مسؤلیت",
        "دعا او توکل","د پیغمبرانو له ژوند څخه درسونه","د اخلاقو اصلاح","د حق او باطل توپیر",
        "د نعمتونو شکر","د زړه پاکوالی","عدالت او د خلکو حقوق","د قرآن لارښوونې","توبه او استغفار",
        "د الله تعالی د قدرت نښې","د ایمان او عمل اړیکه","جنت، دوزخ او د آخرت تیاری",
        "د کورنۍ او ټولنې اصلاح","د آخرت یاد او د نفس اصلاح","اخلاص، تقوا او د آخرت چمتووالی"
    };
    private SharedPreferences prefs;
    private LinearLayout root, content;
    private int green = Color.rgb(35,107,85), dark = Color.rgb(35,58,49), pale = Color.rgb(234,244,239);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(pale);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        prefs = getSharedPreferences("islamic_life", MODE_PRIVATE);
        showHome();
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(dark);
        t.setGravity(Gravity.RIGHT); t.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(8, 8, 8, 8);
        return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void startPage(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(16, 10, 16, 20);
        TextView head = text("🕌  زما اسلامي ژوند", 23, true);
        head.setGravity(Gravity.CENTER); head.setBackgroundColor(pale);
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = text(title, 19, true);
        content.addView(sub);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }
    private void addLine(String s) { content.addView(text(s, 15, false)); }
    private void addTitle(String s) {
        TextView t = text(s, 17, true); t.setTextColor(green);
        content.addView(t);
    }
    private void addBtn(String s, Runnable r) {
        Button b = button(s, r);
        content.addView(b, new LinearLayout.LayoutParams(-1, -2));
    }
    private void addSpace() { content.addView(new View(this), new LinearLayout.LayoutParams(1, 8)); }

    private int todayDay() {
        String key = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        return prefs.getInt("day_" + key, 1);
    }
    private void showHome() {
        startPage("ورځنی ډشبورډ");
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        addLine("نېټه: " + date);
        addLine("دا اپلیکیشن ستا د ۳۰ ورځني عبادت، زده کړې او ځان ارزونې لپاره دی.");
        addTitle("د نن ورځې مهم کارونه");
        addLine("• پنځه وخته لمونځونه");
        addLine("• د قرآن کریم یو پاره");
        addLine("• د سهار او ماښام اذکار");
        addLine("• یوه پټه نېکي او د شپې محاسبه");
        addSpace();
        addBtn("✅ ورځنی چک‌لېست", this::showChecklist);
        addBtn("📖 د قرآن ۳۰ ورځنی پلان", this::showQuran);
        addBtn("📚 د دیني زده کړو نصاب", this::showLessons);
        addBtn("🤲 د پټو نېکیو چلنج", this::showGoodDeeds);
        addBtn("💰 صدقه او مالي یادښتونه", this::showFinance);
        addBtn("🌙 د شپې محاسبه", this::showReflection);
        addBtn("📊 زما پرمختګ", this::showProgress);
        addSpace();
        addLine("یادونه: دا نسخه انټرنېټ او حساب جوړولو ته اړتیا نه لري؛ معلومات په همدې موبایل کې ساتل کېږي.");
    }
    private void showChecklist() {
        startPage("د ورځني عبادت چک‌لېست");
        addLine("د هر کار تر بشپړېدو وروسته یې نښه کړه. ثبت په موبایل کې ساتل کېږي.");
        String dayKey = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        for (int i=0;i<tasks.length;i++) {
            final int ix=i;
            CheckBox cb = new CheckBox(this);
            cb.setText(tasks[i]); cb.setTextSize(15); cb.setTextDirection(View.TEXT_DIRECTION_RTL);
            cb.setGravity(Gravity.RIGHT); cb.setButtonTintList(android.content.res.ColorStateList.valueOf(green));
            cb.setChecked(prefs.getBoolean(dayKey+"_task_"+i, false));
            cb.setOnCheckedChangeListener((v, checked)->prefs.edit().putBoolean(dayKey+"_task_"+ix, checked).apply());
            content.addView(cb);
        }
        addBtn("⬅ بېرته کور ته", this::showHome);
    }
    private void showQuran() {
        startPage("د قرآن کریم ۳۰ ورځنی پلان");
        addLine("هره ورځ یو پاره تلاوت کړه. موضوعات د تدبر عمومي لارښوونې دي.");
        for(int i=0;i<30;i++) {
            final int day=i+1;
            CheckBox cb = new CheckBox(this);
            cb.setText("ورځ "+day+" — "+(day==30?"دېرشمه":pashtoOrdinal(day))+" پاره\nموضوع: "+quranTopics[i]);
            cb.setTextSize(14); cb.setTextDirection(View.TEXT_DIRECTION_RTL); cb.setGravity(Gravity.RIGHT);
            cb.setButtonTintList(android.content.res.ColorStateList.valueOf(green));
            cb.setChecked(prefs.getBoolean("quran_"+day,false));
            cb.setOnCheckedChangeListener((v, checked)->prefs.edit().putBoolean("quran_"+day,checked).apply());
            content.addView(cb);
        }
        addBtn("⬅ بېرته کور ته", this::showHome);
    }
    private String pashtoOrdinal(int n) {
        String[] names={"","لومړۍ","دویمه","درېیمه","څلورمه","پنځمه","شپږمه","اوومه","اتمه","نهمه","لسمه",
        "یوولسمه","دولسمه","دیارلسمه","څوارلسمه","پنځلسمه","شپاړسمه","اوولسمه","اتلسمه","نولسمه","شلمه",
        "یوویشتمه","دوه‌ویشتمه","درویشتمه","څلورویشتمه","پنځه‌ویشتمه","شپږویشتمه","اووه‌ویشتمه","اته‌ویشتمه","نهه‌ویشتمه"};
        return n<names.length?names[n]:"";
    }
    private void showLessons() {
        startPage("د دیني زده کړو ۳۰ ورځنی نصاب");
        String[] titles={"ایمان او اخلاص","د زړه پاکوالی او د نفس اصلاح","د حقوقو ادا کول او د آخرت تیاری","د الله تعالی رضا او دوام"};
        String[][] a={
            {"د نیت اهمیت او د اخلاص معنا","د تقوا معنا او د زړه اصلاح","د الله تعالی مینه؛ نیت او همت","توبه او استغفار","توکل او د اسبابو اختیارول","د صبر فضیلت","د اونۍ بیاکتنه"},
            {"د زړه ناروغۍ او ریا","حسد او کینه","د ژبې ساتنه؛ غیبت او دروغ","د دنیا مینه او زهد","شکر او قناعت","رحمت او بښنه","د زړه د اصلاح بیاکتنه"},
            {"د مور او پلار حقوق","د مېرمنې او اولاد حقوق","پور او امانت","د ناروغانو حقوق او طبي امانتداري","صدقه او پټه نېکي","د مرګ یاد","د خلکو د حقوقو ارزونه"},
            {"دعا او له الله سره اړیکه","د قرآن تدبر","د شپې عبادت","د نېکو اعمالو دوام","صبر او شکر","جنت او له دوزخ څخه پناه","ښه اخلاق او تواضع","د ژوند د هدف ارزونه","د میاشتې بیاکتنه"}
        };
        int day=1;
        for(int w=0;w<4;w++){
            addTitle(titles[w]);
            for(String lesson:a[w]){
                addLine("ورځ "+day+": "+lesson);
                final int d=day;
                CheckBox cb=new CheckBox(this); cb.setText("درس بشپړ شو"); cb.setTextDirection(View.TEXT_DIRECTION_RTL);
                cb.setChecked(prefs.getBoolean("lesson_"+d,false));
                cb.setOnCheckedChangeListener((v, checked)->prefs.edit().putBoolean("lesson_"+d,checked).apply());
                content.addView(cb); day++;
            }
        }
        addLine("هر درس کې د آیت معنا، د صحیح حدیث سرچینه، تشریح او عملي تمرین مطالعه کړه.");
        addBtn("⬅ بېرته کور ته", this::showHome);
    }
    private void showGoodDeeds() {
        startPage("د پټو نېکیو ۳۰ ورځنی چلنج");
        String[] deeds={"د یوه انسان لپاره پټه دعا","د ناروغ مرسته","د مور او پلار خوشحالول","د اړمن اړتیا پوره کول","له غیبت ځان ساتل","د یوه انسان بښل","د مړي لپاره دعا","د ناروغ پوښتنه","د چا عزت ساتل","د ستونزې په حل کې مرسته","له خپلوانو سره اړیکه ښه کول","د ماشوم په ښوونه کې مرسته","د ناروغ لپاره دعا","د اونۍ ارزونه","د امانت ادا کول","په نرمۍ خبرې کول","د اړمن مرسته","د چا عیب پټول","د والدینو خدمت","د ناروغ اضافي مرسته","د خپلوانو د اړتیا پوښتنه","د هدایت دعا","د غوسې کنټرول","مننه یا ستاینه","د خیر په کار کې مرسته","د حق ادا کول","د اړمن خبرې اورېدل","پخلاینه","د وس مطابق صدقه","د نېکو اعمالو بیاکتنه"};
        for(int i=0;i<deeds.length;i++){
            int d=i+1; CheckBox cb=new CheckBox(this);
            cb.setText("ورځ "+d+": "+deeds[i]); cb.setTextDirection(View.TEXT_DIRECTION_RTL); cb.setGravity(Gravity.RIGHT);
            cb.setChecked(prefs.getBoolean("deed_"+d,false));
            cb.setOnCheckedChangeListener((v, checked)->prefs.edit().putBoolean("deed_"+d,checked).apply());
            content.addView(cb);
        }
        addBtn("⬅ بېرته کور ته", this::showHome);
    }
    private void showFinance() {
        startPage("صدقه او مالي یادښتونه");
        addLine("یادونه: نفلي صدقه د وس مطابق ده؛ د کور ضروري لګښتونه او پورونه مه زیانمنوه.");
        addTitle("د نن ورځې مالي یادښت");
        EditText amount = new EditText(this); amount.setHint("د صدقې اندازه (افغانۍ)"); amount.setInputType(2);
        amount.setText(prefs.getString("finance_amount","")); content.addView(amount);
        EditText note = new EditText(this); note.setHint("د صدقې ډول یا غیرمالي نېکي"); note.setText(prefs.getString("finance_note","")); content.addView(note);
        EditText debt = new EditText(this); debt.setHint("د پور د ادا کولو یادښت"); debt.setText(prefs.getString("finance_debt","")); content.addView(debt);
        addBtn("💾 یادښتونه خوندي کړه", ()->{
            prefs.edit().putString("finance_amount",amount.getText().toString())
                .putString("finance_note",note.getText().toString())
                .putString("finance_debt",debt.getText().toString()).apply();
            Toast.makeText(this,"یادښتونه خوندي شول",Toast.LENGTH_SHORT).show();
        });
        addBtn("⬅ بېرته کور ته", this::showHome);
    }
    private void showReflection() {
        startPage("د شپې محاسبه");
        String[] qs={"نن مې کوم عمل د الله د رضا لپاره وکړ؟","آیا د چا حق مې ضایع کړی؟ څنګه یې ادا کوم؟",
            "زما د کار له امله چا ته ګټه ورسېده؟","کوم اخلاق یا عادت باید اصلاح کړم؟",
            "سبا به کوم یو عمل اصلاح کوم؟","آیا زما نیت د الله رضا ده؟"};
        EditText[] fields=new EditText[qs.length];
        for(int i=0;i<qs.length;i++){
            addLine((i+1)+". "+qs[i]);
            fields[i]=new EditText(this); fields[i].setMinLines(2); fields[i].setGravity(Gravity.TOP|Gravity.RIGHT);
            fields[i].setTextDirection(View.TEXT_DIRECTION_RTL);
            fields[i].setText(prefs.getString("reflection_"+i,""));
            content.addView(fields[i]);
        }
        addBtn("💾 محاسبه خوندي کړه", ()->{
            SharedPreferences.Editor e=prefs.edit();
            for(int i=0;i<fields.length;i++) e.putString("reflection_"+i,fields[i].getText().toString());
            e.apply(); Toast.makeText(this,"محاسبه خوندي شوه",Toast.LENGTH_SHORT).show();
        });
        addBtn("⬅ بېرته کور ته", this::showHome);
    }
    private void showProgress() {
        startPage("زما پرمختګ");
        int q=0,l=0,d=0;
        for(int i=1;i<=30;i++){if(prefs.getBoolean("quran_"+i,false))q++; if(prefs.getBoolean("deed_"+i,false))d++;}
        for(int i=1;i<=30;i++) if(prefs.getBoolean("lesson_"+i,false)) l++;
        addTitle("د ۳۰ ورځو تعقیب");
        addLine("د قرآن تلاوت بشپړې شوې ورځې: "+q+" / 30");
        addLine("بشپړ شوي دیني درسونه: "+l+" / 30");
        addLine("ترسره شوې پټې نېکۍ: "+d+" / 30");
        addLine("د پرمختګ اندازه د ځان هڅونې لپاره ده، نه د عبادت د قبولیت د اندازې لپاره.");
        addBtn("⬅ بېرته کور ته", this::showHome);
    }
}
