د موبایل له لارې APK جوړولو لپاره (کمپیوټر ته اړتیا نه لري):
1. په GitHub.com کې وړیا حساب جوړ/خلاص کړئ.
2. نوی Repository جوړ کړئ؛ نوم یې IslamicLifeApp کېږدئ او Public یا Private انتخاب کړئ.
3. د دې ZIP دننه د IslamicLifeApp_Android فولډر ټول فایلونه (د .github پټ فولډر په ګډون) خپل Repository ته Upload کړئ. د GitHub په موبایلي ویب پاڼه کې دا کار لږ ستونزمن کېدای شي.
4. Repository کې Actions ټب خلاص کړئ، "Build Android APK" انتخاب کړئ او "Run workflow" ووهئ.
5. Build بشپړ شي، د هماغه اجرا په پاڼه کې Artifacts برخه کې "IslamicLifeApp-debug-apk" ډاونلوډ کړئ.
6. د ZIP دننه app-debug.apk به وي. په Samsung کې یې پرانیزئ او د اړتیا په صورت کې Settings کې "Install unknown apps" اجازه ورکړئ؛ یوازې هغه APK نصب کړئ چې د خپل Repository د Build څخه مو ترلاسه کړی وي.

مهم: دا workflow د APK د جوړولو اتومات لار ده، نه تیار APK. Build لا باید په GitHub کې وچلول شي. د پروژې د بریالي Build ضمانت نه شم ورکولی تر څو هلته اجرا او ازمویل شوې نه وي.
