package com.example.islamiclife;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root, content;
    private final int green = Color.rgb(29, 104, 78), dark = Color.rgb(35, 55, 46), pale = Color.rgb(231, 244, 237);
    private final String[] tasks = {
        "پنځه وخته لمونځونه", "د سهار اذکار", "د ماښام اذکار", "د قرآن کریم یو پاره",
        "د قرآن معنا/تفسیر مطالعه", "نبوي سیرت درس", "د الفوائد درس", "استغفار او توبه",
        "د مور او پلار/کورنۍ خدمت", "یوه پټه نېکي", "د ژبې ساتنه", "د شپې محاسبه"
    };
    private final String[] quranTopics = {
        "نیت، اخلاص او د قرآن هدایت","تقوا او د الله اطاعت","د مومنانو صفتونه","رحمت او مغفرت",
        "د کورنۍ او ټولنې حقوق","صبر او ثابت قدمي","د الله نعمتونه او شکر","د پیغمبرانو کیسې",
        "توبه او اصلاح","د عمل او نیت ارزښت","توکل او د اسبابو اختیارول","حق او باطل",
        "د آخرت یاد","د انسان مسؤلیت","دعا او عبادت","د زړه پاکوالی","اخلاق او عدالت",
        "د الله قدرت","د نعمتونو شکر","د صبر پایله","د خلکو حقوق","د قرآن عملي لارښوونې",
        "د استغفار اهمیت","د ایمان او عمل اړیکه","جنت او دوزخ","د کورنۍ اصلاح",
        "د نفس محاسبه","د تقوا نښې","د آخرت تیاری","اخلاص او دوام"
    };
    private final String[] seerah = {
        "د مکې ټولنه د بعثت نه مخکې: امانت، نسب او د ټولنې حالت.",
        "د رسول الله ﷺ زېږون او ماشومتوب: د ژوند له لومړیو پړاوونو څخه عبرت.",
        "د ځوانۍ امانتداري: د الصادق الأمین لقب او د اعتماد ارزښت.",
        "د حرا غار او د وحی پیل: د علم او رسالت عظمت.",
        "د لومړنیو مسلمانانو دعوت: حکمت، صبر او اخلاص.",
        "د پټې او علني دعوت مرحلې: د دعوت اصول او زغم.",
        "د مسلمانانو ازار او صبر: د ایمان د ثابت پاتې کېدو درس.",
        "هجرت حبشې ته: عدالت ته پناه او د دین ساتنه.",
        "د شعب ابی طالب محاصره: صبر او د کورنۍ ملاتړ.",
        "عام الحزن: د غم پر مهال توکل او امید.",
        "طائف ته سفر: د اذیت په وړاندې رحمت او دعا.",
        "اسراء او معراج: د لمانځه اهمیت.",
        "د مدینې د خلکو بیعت: د نصرت او مسؤلیت معنا.",
        "هجرت مدینې ته: توکل، تدبیر او ورورولي.",
        "د مسجد نبوي جوړول: د ټولنې بنسټونه.",
        "مواخات او د مدینې تړون: ورورولي او ګډ ژوند.",
        "بدر: د ایمان، دعا او نظم درس.",
        "احد: د اطاعت او تېروتنو د پایلو درس.",
        "خندق: مشوره، هڅه او اتحاد.",
        "حدیبیه: حکمت، صبر او اوږدمهاله بریا.",
        "د سولې او دعوت لیکونه: د پیغام رسولو اصول.",
        "خیبر او د ټولنې امنیت: د تاریخ د پېښو له سیاق سره مطالعه.",
        "فتح مکه: عفو، تواضع او د قدرت پر مهال اخلاق.",
        "حنین: د شمېر پر ځای پر الله توکل.",
        "د تبوک غزا: قرباني او د منافقت نښې.",
        "د وفود کال: د دعوت او تعلیم پراختیا.",
        "د رسول الله ﷺ اخلاق: رحمت، رښتینولي او نرمۍ.",
        "د کورنۍ سره چلند: مینه، عدالت او ښه اخلاق.",
        "د خطبة الوداع مهم پیغامونه: د انسانانو حقوق.",
        "د رسول الله ﷺ له سیرت څخه د ژوند لپاره ۵ عملي درسونه."
    };
    private final String[] fawaid = {
        "نیت او همت: د انسان موخه باید د الله رضا وي؛ د نن ورځې نیت په یوه جمله ولیکه.",
        "د زړه ژوند: د قرآن تلاوت، ذکر او توبه د زړه د اصلاح سببونه دي.",
        "اخلاص: عمل د خلکو د ستاینې لپاره مه کوه؛ یوه پټه نېکي ترسره کړه.",
        "د نفس محاسبه: د ورځې یوه تېروتنه وپېژنه او د اصلاح ګام ولیکه.",
        "د دنیا لنډوالی: د آخرت لپاره یو دوامدار عمل وټاکه.",
        "صبر: د ستونزې پر مهال حرامه لاره مه غوره کوه؛ حلال اسباب وکاروه.",
        "شکر: درې نعمتونه ولیکه او د یوه نعمت شکر په عمل کې ادا کړه.",
        "توکل: لومړی روا اسباب وکاروه، بیا پر الله اعتماد وکړه.",
        "د ژبې ساتنه: نن له غیبت، دروغو او بې ګټې خبرو ځان وساته.",
        "د خلکو حقوق: که د چا حق درباندې وي، د ادا کولو عملي پلان جوړ کړه.",
        "توبه: ګناه پرېښودل، پښېماني او د نه تکرار کلک عزم.",
        "د نیت تجدید: د کار تر پیل مخکې د الله رضا په زړه کې تازه کړه.",
        "د وخت قدر: د ورځې ۱۵ دقیقې د علم او ذکر لپاره خوندي کړه.",
        "حسد: د بل د نعمت په لیدو ورته د برکت دعا وکړه.",
        "قناعت: د نعمتونو قدر وکړه او له اسرافه ځان وساته.",
        "دعا: خپلې اړتیاوې له الله وغواړه او د دعا آداب مراعات کړه.",
        "د قرآن تدبر: یو آیت ولوله، معنا یې زده کړه او یو عمل ترې واخله.",
        "رحمت: له کورنۍ او خلکو سره نرمي غوره کړه.",
        "د مرګ یاد: د توبې او د خلکو د حقوقو د ادا کولو یو ګام واخله.",
        "دوام: لږ خو دوامدار نېک عمل غوره کړه.",
        "امانت: په کار، طبابت او خبرو کې امانتداري وساته.",
        "د والدینو خدمت: د هغوی د خوشحالۍ لپاره یو مشخص کار وکړه.",
        "د قهر کنټرول: د غوسې پر مهال چوپتیا او د حالت بدلول تمرین کړه.",
        "تواضع: د حق خبره ومنه که له هر چا وي.",
        "صدقه: د وس مطابق مالي یا غیرمالي مرسته وکړه.",
        "د زړه پاکوالی: کینه پرېږده او د مسلمان لپاره دعا وکړه.",
        "د آخرت توازن: د کورنۍ حقونه او د عبادت حقونه دواړه ادا کړه.",
        "ښه اخلاق: په خبرو کې رښتینولي او نرمۍ ته پام وکړه.",
        "د نیت او عمل اړیکه: نن یو عمل په اخلاص ترسره کړه.",
        "میاشتنۍ بیاکتنه: هغه درې عادتونه وټاکه چې راتلونکې میاشت به دوام ورکوې."
    };
    private final String[] tafsir = {
        "الفاتحه 1:5 — إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ. معنا: یوازې ستا عبادت کوو او یوازې له تا مرسته غواړو. عملي درس: عبادت او توکل یوځای وساته.",
        "البقرة 2:21 — د عبادت بلنه: د خالق عبادت د انسان د ژوند اساسي هدف دی.",
        "البقرة 2:286 — الله هېڅ نفس تر وس پورته نه مکلفوي. عملي درس: په ستونزه کې د وس مطابق هڅه او دعا.",
        "آل عمران 3:134 — غوسه زغمل او خلک بښل د نېکانو له صفتونو دي.",
        "النساء 4:36 — د الله عبادت او له والدینو، خپلوانو، یتیمانو او اړمنو سره احسان.",
        "المائدة 5:8 — عدالت وساتئ؛ د چا دښمني دې بې‌عدالتي ته اړ نه کړي.",
        "الأنعام 6:162 — لمونځ، قرباني، ژوند او مرګ د الله لپاره.",
        "الأعراف 7:56 — په ځمکه کې له اصلاح وروسته فساد مه کوئ؛ دعا له وېرې او امید سره.",
        "التوبة 9:119 — له رښتینو خلکو سره اوسئ؛ رښتینولي د ایمان مهمه نښه ده.",
        "يونس 10:57 — قرآن د زړونو لپاره نصیحت، شفا او هدایت دی.",
        "الرعد 13:28 — د الله په یاد زړونه ډاډ مومي.",
        "النحل 16:90 — الله د عدالت، احسان او خپلوانو د حق ادا کولو امر کوي.",
        "الإسراء 17:23 — له الله سره شرک مه کوئ او له والدینو سره احسان وکړئ.",
        "الكهف 18:110 — د صالح عمل لپاره اخلاص او د الله له عبادت سره شریک نه نیول.",
        "طه 20:114 — د علم د زیاتېدو دعا: رَبِّ زِدْنِي عِلْمًا.",
        "الأنبياء 21:107 — رسول الله ﷺ د نړۍ لپاره رحمت رالېږل شوی.",
        "المؤمنون 23:1-11 — د کامیابو مؤمنانو مهم صفتونه؛ لمونځ او امانتداري.",
        "النور 24:22 — بښنه او تېرېدنه؛ د الله د بښنې هیله.",
        "الفرقان 25:63 — د رحمان بندګان په تواضع ګرځي او په نرمه خبره ځواب ورکوي.",
        "العنكبوت 29:69 — څوک چې زموږ په لار کې هڅه کوي، الله ورته لارې ښيي.",
        "لقمان 31:14 — له والدینو سره احسان او شکر.",
        "الأحزاب 33:21 — د رسول الله ﷺ په ژوند کې د مؤمنانو لپاره غوره بېلګه.",
        "الزمر 39:53 — د الله له رحمته مه ناامېده کېږئ؛ توبه وباسئ.",
        "الشورى 42:40 — بښنه او اصلاح د اجر وړ دي.",
        "الحجرات 49:10 — مؤمنان وروڼه دي؛ پخلاینه وکړئ.",
        "الحجرات 49:12 — له بدګومانۍ، تجسس او غیبت څخه ځان وساتئ.",
        "الحديد 57:20 — د دنیا ژوند لنډ او تېرېدونکی دی؛ د آخرت لپاره تیاری.",
        "الجمعة 62:10 — له لمانځه وروسته د حلال رزق لټون او د الله ډېر یاد.",
        "الملك 67:2 — ژوند او مرګ د دې لپاره چې معلومه شي څوک غوره عمل کوي.",
        "العصر 103:1-3 — ایمان، نېک عمل، حق او صبر د تاوان څخه د ژغورنې لارې دي."
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("islamic_life_v2", MODE_PRIVATE);
        getWindow().setStatusBarColor(pale);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        showHome();
    }
    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    private String month() { return new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date()); }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark);
        t.setGravity(Gravity.RIGHT); t.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(8, 8, 8, 8); return t;
    }
    private Button button(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(15);
        b.setOnClickListener(v -> r.run()); return b;
    }
    private void startPage(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16, 10, 16, 20);
        TextView head = text("🕌 زما اسلامي ژوند", 23, true); head.setGravity(Gravity.CENTER); head.setBackgroundColor(pale);
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));
        content.addView(text(title, 19, true)); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }
    private void line(String s) { content.addView(text(s, 15, false)); }
    private void title(String s) { TextView t=text(s,17,true); t.setTextColor(green); content.addView(t); }
    private void btn(String s, Runnable r) { content.addView(button(s,r),new LinearLayout.LayoutParams(-1,-2)); }
    private void back() { btn("⬅ بېرته کور ته",this::showHome); }
    private void showHome() {
        startPage("ورځنی ډشبورډ");
        line("نېټه: "+today()); line("ستاسې عبادتونه او یادښتونه په همدې موبایل کې خوندي کېږي.");
        title("د نن ورځې مهم کارونه"); line("لمونځونه • قرآن • اذکار • علم • د خلکو حقوق • د شپې محاسبه");
        btn("✅ د نن ورځې اعمال",this::checklist);
        btn("📖 د قرآن تلاوت او تدبر (۳۰ ورځې)",this::quranPage);
        btn("📜 نبوي سیرت — ۳۰ درسونه",this::seerahPage);
        btn("📚 د ابن القیم رحمه الله «الفوائد» — ۳۰ تأملي درسونه",this::fawaidPage);
        btn("📘 د قرآن د تفسیر مطالعې لارښود",this::tafsirPage);
        btn("🤲 د پټو نېکیو ۳۰ ورځنی چلنج",this::deedsPage);
        btn("🌙 د شپې محاسبه",this::reflectionPage);
        btn("📊 میاشتنی راپور جوړول او شریکول",this::monthlyReport);
        line("مهم: دا د مطالعې لنډیزونه او عملي تأملونه دي؛ د آیتونو بشپړ تفسیر او د سیرت/الفوائد کره نقل لپاره معتبره چاپي سرچینه هم وګورئ.");
    }
    private void checklist() {
        startPage("د نن ورځې اعمال"); line("د هر عمل تر بشپړېدو وروسته نښه کړه. د هرې نېټې ثبت جلا ساتل کېږي.");
        String d=today();
        for(int i=0;i<tasks.length;i++){ final int x=i; CheckBox c=new CheckBox(this); c.setText(tasks[i]); c.setTextSize(15); c.setTextDirection(View.TEXT_DIRECTION_RTL); c.setGravity(Gravity.RIGHT);
            c.setChecked(prefs.getBoolean(d+"_task_"+i,false)); c.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean(d+"_task_"+x,on).apply()); content.addView(c); }
        back();
    }
    private void quranPage() {
        startPage("د قرآن ۳۰ ورځنی تلاوت او تدبر"); line("هره ورځ یو پاره تلاوت کړئ؛ موضوع د تدبر لپاره ده، د آیتونو بدیل تفسیر نه دی.");
        for(int i=0;i<30;i++){ final int n=i+1; CheckBox c=new CheckBox(this); c.setText("ورځ "+n+" — پاره "+n+"\nد تدبر موضوع: "+quranTopics[i]); c.setTextDirection(View.TEXT_DIRECTION_RTL); c.setGravity(Gravity.RIGHT);
            c.setChecked(prefs.getBoolean("quran_"+n,false)); c.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean("quran_"+n,on).apply()); content.addView(c); }
        back();
    }
    private void contentLessons(String page, String[] items, String prefix) {
        startPage(page); line("درسونه په خپله ژبه ولوله، د معتبرې سرچینې سره یې پرتله کړه او عملي درس یادداشت کړه.");
        for(int i=0;i<items.length;i++){ final int n=i+1; title("درس "+n); line(items[i]);
            CheckBox c=new CheckBox(this); c.setText("درس مطالعه شو"); c.setTextDirection(View.TEXT_DIRECTION_RTL);
            c.setChecked(prefs.getBoolean(prefix+n,false)); c.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean(prefix+n,on).apply()); content.addView(c);
            EditText note=new EditText(this); note.setHint("زما عملي یادښت (اختیاري)"); note.setMinLines(1); note.setTextDirection(View.TEXT_DIRECTION_RTL);
            note.setText(prefs.getString(prefix+"note"+n,"")); content.addView(note);
            btn("یادښت خوندي کړه",()->{prefs.edit().putString(prefix+"note"+n,note.getText().toString()).apply(); Toast.makeText(this,"خوندي شو",Toast.LENGTH_SHORT).show();});
        } back();
    }
    private void seerahPage(){contentLessons("نبوي سیرت — ۳۰ درسونه",seerah,"seerah_");}
    private void fawaidPage(){contentLessons("د الفوائد الهام‌اخیستونکي تأملات",fawaid,"fawaid_");}
    private void tafsirPage(){contentLessons("د قرآن د تفسیر د مطالعې لارښود",tafsir,"tafsir_");}
    private void deedsPage(){
        startPage("د پټو نېکیو ۳۰ ورځنی چلنج");
        String[] d={"د یوه انسان لپاره پټه دعا","د مور او پلار خدمت","د ناروغ پوښتنه","له غیبت ځان ساتل","د اړمن مرسته","د چا بښل","د خپلوانو پوښتنه","د امانت ادا کول","په نرمه ژبه خبرې","د چا عیب پټول","د ماشوم په زده کړه کې مرسته","د ناروغ لپاره دعا","د غوسې کنټرول","د چا خبرې په حوصله اورېدل","د وس مطابق صدقه","پخلاینه کول","د چا عزت ساتل","د اړمن لپاره لارښوونه","د کورنۍ مرسته","د خیر کار ته هڅونه","د حق ادا کولو ګام","د چا لپاره د هدایت دعا","د وخت یا مهارت مرسته","له اسرافه ځان ساتل","مننه او قدرداني","د یوه انسان زړه خوشحالول","د قرض ادا کولو پلان","د ناروغ/کمزوري ملاتړ","پټه دعا او استغفار","د میاشتې بیاکتنه"};
        for(int i=0;i<30;i++){final int n=i+1; CheckBox c=new CheckBox(this); c.setText("ورځ "+n+": "+d[i]); c.setTextDirection(View.TEXT_DIRECTION_RTL); c.setGravity(Gravity.RIGHT);
            c.setChecked(prefs.getBoolean("deed_"+n,false)); c.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean("deed_"+n,on).apply()); content.addView(c);}
        back();
    }
    private void reflectionPage(){
        startPage("د نن ورځې محاسبه"); String[] qs={"نن مې د الله د رضا لپاره کوم عمل وکړ؟","د چا حق مې پاتې دی؟ د ادا کولو ګام یې څه دی؟","نن مې کومه تېروتنه وکړه او څنګه یې اصلاح کوم؟","سبا به کوم یو عمل ښه کوم؟"};
        EditText[] e=new EditText[qs.length]; String d=today();
        for(int i=0;i<qs.length;i++){line((i+1)+". "+qs[i]); e[i]=new EditText(this); e[i].setMinLines(2); e[i].setGravity(Gravity.RIGHT|Gravity.TOP); e[i].setTextDirection(View.TEXT_DIRECTION_RTL); e[i].setText(prefs.getString(d+"_reflection_"+i,"")); content.addView(e[i]);}
        btn("💾 محاسبه خوندي کړه",()->{SharedPreferences.Editor ed=prefs.edit();for(int i=0;i<e.length;i++)ed.putString(d+"_reflection_"+i,e[i].getText().toString());ed.apply();Toast.makeText(this,"محاسبه خوندي شوه",Toast.LENGTH_SHORT).show();}); back();
    }
    private void monthlyReport(){
        startPage("میاشتنی راپور"); String m=month(); int completed=0,total=0,q=0,ser=0,faw=0,taf=0,deed=0;
        Calendar cal=Calendar.getInstance(); int days=cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(int day=1;day<=days;day++){String d=m+"-"+String.format(Locale.US,"%02d",day);
            for(int i=0;i<tasks.length;i++){total++; if(prefs.getBoolean(d+"_task_"+i,false))completed++;}
        }
        for(int i=1;i<=30;i++){if(prefs.getBoolean("quran_"+i,false))q++;if(prefs.getBoolean("seerah_"+i,false))ser++;if(prefs.getBoolean("fawaid_"+i,false))faw++;if(prefs.getBoolean("tafsir_"+i,false))taf++;if(prefs.getBoolean("deed_"+i,false))deed++;}
        int pct=total==0?0:(completed*100/total);
        String report="زما اسلامي ژوند — میاشتنی راپور\nمیاشت: "+m+"\nد ورځنیو اعمالو ثبت: "+completed+" / "+total+" ("+pct+"%)\nد قرآن د تلاوت نښه شوې ورځې: "+q+"/30\nد نبوي سیرت بشپړ درسونه: "+ser+"/30\nد الفوائد تأملات: "+faw+"/30\nد تفسیر د مطالعې نښې: "+taf+"/30\nد پټو نېکیو نښې: "+deed+"/30\n\nیادونه: دا د شخصي تعقیب راپور دی؛ د عبادت د قبولیت معیار نه دی. الله دې اعمال قبول کړي.";
        line(report);
        btn("📤 راپور شریکول",()->{Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_SUBJECT,"زما اسلامي ژوند — میاشتنی راپور");send.putExtra(Intent.EXTRA_TEXT,report);startActivity(Intent.createChooser(send,"راپور له چا سره شریک کړئ"));});
        btn("📋 راپور کاپي کول",()->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText("monthly report",report));Toast.makeText(this,"راپور کاپي شو",Toast.LENGTH_SHORT).show();});
        line("معلومات د موبایل په حافظه کې ساتل کېږي. د اپلیکیشن شریکول ستا شخصي ثبتونه له نورو سره نه شریکوي.");
        back();
    }
}
